import Exercicios.MediaGolos;

public class Principal {


	public static void main(String[] args) {
		new MediaGolos();

	}

}

import java.util.Scanner;

public class Principal {


	public static void main(String[] args) {
		
		float preco, total = 0; 
		String nome;
		Artigo[] art = new Artigo[3];
		
		for (int i = 0; i < 3 ; i++)
		{
			System.out.println("Introduza o nome do " + (i+1) + "� Artigo e de seguida o seu valor");
			nome = new Scanner(System.in).nextLine();
			preco = new Scanner(System.in).nextInt();
			art[i] = new Artigo(nome, preco);
		}
		
		total += art[0].getPreco() + art[1].getPreco() + art[2].getPreco();
		
		System.out.println("O valor total dos artigos e " + total + "�");

	}

}

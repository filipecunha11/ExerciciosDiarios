
public class Artigo {

	private float preco;
	private String nome;	
	
	public Artigo(String nome, float preco) {
		this.nome = nome;
		this.preco = preco;
	}

	public String getNome(){
		return nome;
	}
	
	public void setNome(String nome){
		this.nome = nome;
	}
	
	public double getPreco(){
		return preco;
	}
	
	public void setPreco(float preco){
		this.preco = preco;
	}

}

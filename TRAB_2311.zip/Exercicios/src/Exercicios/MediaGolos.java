package Exercicios;

import java.text.DecimalFormat;
import java.util.Random;	
import java.util.Scanner;

public class MediaGolos {

	public MediaGolos() {
		//Assumindo que h� um jogo em casa e outro fora
		int[][] resultados = new int[12][2];
		float panda, caricas, bob, pocoyo;
		Random r = new Random();
		
		for (int i = 0 ; i < 12; i++)
		{
			for ( int l = 0; l < 2; l++)
			{
				resultados[i][l] = r.nextInt(4);
			}
		}
		
		System.out.println("Campeonato Futebol Praia de Braga - Resultados");
		System.out.println("             Jornada 1");
		System.out.println(" Panda   "+ resultados[0][0] + "	-	"+ resultados[0][1] + " Caricas" );
		System.out.println(" Caricas "+ resultados[1][0] + "	-	"+ resultados[1][1] + "     Bob" );
		System.out.println(" Bob     "+ resultados[2][0] + "	-	"+ resultados[2][1] + "  Pocoyo");
		System.out.println(" Pocoyo  "+ resultados[3][0] + "	-	"+ resultados[3][1] + "   Panda" );
		
		System.out.println("             Jornada 2");
		System.out.println(" Panda	 "+ resultados[4][0] + "	-	"+ resultados[4][1] + "     Bob" );
		System.out.println(" Caricas "+ resultados[5][0] + "	-	"+ resultados[5][1] + "  Pocoyo" );
		System.out.println(" Bob     "+ resultados[6][0] + "	-	"+ resultados[6][1] + "   Panda" );
		System.out.println(" Pocoyo	 "+ resultados[7][0] + "	-	"+ resultados[7][1] + " Caricas" );
		
		System.out.println("             Jornada 3");
		System.out.println(" Panda   "+ resultados[8][0] + "	-	"+ resultados[8][1] + "  Pocoyo" );
		System.out.println(" Bob     "+ resultados[9][0] + "	-	"+ resultados[9][1] + " Caricas" );
		System.out.println(" Pocoyo	 "+ resultados[10][0] + "	-	"+ resultados[10][1] + "     Bob" );
		System.out.println(" Caricas "+ resultados[11][0] + "	-	"+ resultados[11][1] + "   Panda" );
		
		panda = ( resultados[0][0] + resultados[3][1] + resultados[4][0] + resultados[6][1] + resultados[8][0] + resultados[11][1] ) / 6f;
		pocoyo = ( resultados[3][0] + resultados[2][1] + resultados[5][1] + resultados[7][0] + resultados[8][1] + resultados[10][0] ) / 6f;
		bob = ( resultados[1][1] + resultados[2][0] + resultados[4][1] + resultados[6][0] + resultados[9][0] + resultados[10][1] ) / 6f;
		caricas = ( resultados[0][1] + resultados[1][0] + resultados[5][0] + resultados[7][1] + resultados[9][1] + resultados[11][0]) / 6f;
		
		DecimalFormat df = new DecimalFormat("#.##"); //Procurado na internet
		System.out.println("\n\nMedia Golos Panda	-	" + df.format(panda));
		System.out.println("Media Golos Pocoyo	-	" + df.format(pocoyo));
		System.out.println("Media Golos Bob		-	" + df.format(bob));
		System.out.println("Media Golos Caricas	-	" + df.format(caricas));
	}

}

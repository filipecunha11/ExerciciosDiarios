package Exercicios;
import java.util.Scanner;

public class CalculadoraGastos {

	public CalculadoraGastos() {
		
		float agua, luz, gas, tele, media;
		
		System.out.println("Insira uma m�dia mensal de cada uma das seguintes despesas: ");
		
		System.out.print("�gua:"	);
		agua = (new Scanner(System.in)).nextFloat();
		
		System.out.print("Luz :"	);
		luz = (new Scanner(System.in)).nextFloat();
		
		System.out.print("G�s :"	);
		gas = (new Scanner(System.in)).nextFloat();
		
		System.out.print("Telecomunica��es:"	);
		tele = (new Scanner(System.in)).nextFloat();
		
		media = ((agua+luz+gas+tele)*12)/4;
		
		System.out.println("A m�dia das suas despesas anualmente �: " + media + " �.");
	}

}
